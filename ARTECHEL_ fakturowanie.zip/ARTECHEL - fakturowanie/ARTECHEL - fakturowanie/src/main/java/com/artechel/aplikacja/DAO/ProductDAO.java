package com.artechel.aplikacja.DAO;

import com.artechel.aplikacja.model.Product;

import java.util.List;

public interface ProductDAO {

    List<Product> listProducts();
}
